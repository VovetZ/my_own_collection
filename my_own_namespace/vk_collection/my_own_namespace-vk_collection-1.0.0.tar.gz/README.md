# Ansible Collection - my_own_namespace.vk_collection

Documentation for the collection.
